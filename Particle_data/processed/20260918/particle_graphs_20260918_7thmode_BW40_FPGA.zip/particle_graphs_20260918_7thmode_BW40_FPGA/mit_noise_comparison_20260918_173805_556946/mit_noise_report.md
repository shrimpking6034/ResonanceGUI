# MIT 논문 방식 노이즈 비교

원본: `C:\Users\user\Desktop\김세호\ResonanceGUI\raw_20260918_170943_7c4245f9_BW40_2.csv`

피크 사이 baseline에 1 Hz, 2차 Butterworth high-pass를 적용하고 각 구간 평균을 제거한 뒤 시간영역 표준편차(ddof=1)를 계산했습니다.

통합 σ: 0.112472 Hz
유효 구간: 13 / 13
Supplement Fig. S5 전체 평균 ≈ 0.0225 Hz 대비: 5×

논문 평균값은 합격/불합격 기준이 아닙니다.
